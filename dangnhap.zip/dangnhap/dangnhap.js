
// Tác giả: Trần Nguyễn Thanh Điền
// MSSV: B2303739
//Tác giả: Nguyễn Thanh Lợi
//MSSV: B2305586



// Xử lý đăng nhập
document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value;

  // Kiểm tra dữ liệu đầu vào
  if (!username || !password) {
    const messageDiv = document.getElementById("message");
    messageDiv.textContent = "Vui lòng nhập đầy đủ thông tin!";
    messageDiv.classList.remove("success");
    messageDiv.classList.add("error");
    messageDiv.style.display = "block";
    return;
  }

  // Lấy thông tin đã lưu từ localStorage
  const savedUsername = localStorage.getItem("savedemail");
  const savedPassword = localStorage.getItem("savedpassword");

  const messageDiv = document.getElementById("message");

  const isAdmin = username === "admin" && password === "admin";
  const isSaved = username === savedUsername && password === savedPassword;

  if (isAdmin || isSaved) {
    messageDiv.textContent = "Đăng nhập thành công! Đang chuyển hướng...";
    messageDiv.classList.remove("error");
    messageDiv.classList.add("success");
    messageDiv.style.display = "block";
    
    // Lưu trạng thái đăng nhập
    localStorage.setItem("isLoggedIn", "true");
    localStorage.setItem("currentUser", username);
    
    // Chuyển hướng sau 2 giây
    setTimeout(() => {
      window.location.href = "../index.html";
    }, 2000);
  } else {
    messageDiv.textContent = "Tên đăng nhập hoặc mật khẩu không đúng!";
    messageDiv.classList.remove("success");
    messageDiv.classList.add("error");
    messageDiv.style.display = "block";
    
    // Xóa mật khẩu để người dùng nhập lại
    document.getElementById("login-password").value = "";
    document.getElementById("login-password").focus();
  }
});

// Kiểm tra nếu đã đăng nhập thì hiển thị thông báo
document.addEventListener("DOMContentLoaded", function() {
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  if (isLoggedIn === "true") {
    const messageDiv = document.getElementById("message");
    messageDiv.textContent = "Bạn đã đăng nhập! Nếu muốn đăng nhập tài khoản khác, vui lòng đăng xuất trước.";
    messageDiv.classList.remove("error");
    messageDiv.classList.add("success");
    messageDiv.style.display = "block";
  }
});

// Thêm chức năng đăng xuất (có thể sử dụng ở các trang khác)
function logout() {
  localStorage.removeItem("isLoggedIn");
  localStorage.removeItem("currentUser");
  window.location.href = "dangnhap.html";
}

// Thêm chức năng kiểm tra trạng thái đăng nhập
function checkLoginStatus() {
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  return isLoggedIn === "true";
}
