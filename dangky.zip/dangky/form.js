

// Tác giả: Lâm Tuấn Hưng
// MSSV: B2303818


//Hàm dùng chung cho trạng thái của email và password
function setFeedback(
  element,
  messageElement,
  type,
  message,
  inputClassPrefix, //dùng để chỉnh sửa class của ô input
  msgClassPrefix //dùng để chỉnh sửa class của thông báo trạng thái
) {
  // reset class
  if (inputClassPrefix) {
    element.classList.remove(
      `${inputClassPrefix}-error-input`,
      `${inputClassPrefix}-success-input`
    );
  }

  if (msgClassPrefix) {
    messageElement.classList.remove(
      `${msgClassPrefix}-error`,
      `${msgClassPrefix}-success`
    );
  }

  // set class mới
  if (type === "error") {
    if (inputClassPrefix)
      element.classList.add(`${inputClassPrefix}-error-input`);
    if (msgClassPrefix) messageElement.classList.add(`${msgClassPrefix}-error`);
  } else {
    if (inputClassPrefix)
      element.classList.add(`${inputClassPrefix}-success-input`);
    if (msgClassPrefix)
      messageElement.classList.add(`${msgClassPrefix}-success`);
  }

  // gán nội dung thông báo
  if (message) messageElement.textContent = message;
}

//check tên đăng nhập
document.getElementById("username").addEventListener("blur", function () {
  if (this.value === "") {
    setFeedback(this, null, "error", "", "pw", null);
  } else {
    setFeedback(this, null, "success", "", "pw", null);
  }
});
//Check password rỗng
document.getElementById("password").addEventListener("blur", function () {
  if (this.value === "") {
    setFeedback(
      this,
      document.getElementById("confirm-error"),
      "error",
      "Mật khẩu không được để trống!",
      "pw",
      "pw"
    );
  }
});
//check password có khớp hay không
document
  .getElementById("confirm-password")
  .addEventListener("blur", function () {
    const password = document.getElementById("password").value;
    const confirmPassword = this.value;

    if (password !== confirmPassword || confirmPassword === "") {
      setFeedback(
        this,
        document.getElementById("confirm-error"),
        "error",
        "Mật khẩu xác nhận không khớp!",
        "pw",
        "pw"
      );
      document.getElementById("password").classList.add("pw-error-input");
    } else {
      setFeedback(
        this,
        document.getElementById("confirm-error"),
        "success",
        "Mật khẩu hợp lệ!",
        "pw",
        "pw"
      );
      document.getElementById("password").classList.add("pw-success-input");
    }
  });
// Check email hợp lệ
document.getElementById("email").addEventListener("blur", function () {
  const email = this.value;
  const isValid = validateEmail(email);
  setFeedback(
    this,
    document.getElementById("email-check"),
    isValid ? "success" : "error",
    isValid ? "Email hợp lệ!" : "Email không hợp lệ!",
    "email",
    "email"
  );
});
//Tham khảo tài liệu CT188-Phần 2: Tài liệu hỗ trợ học lập trình
//kiểm tra tính hợp lệ của email
function validateEmail(email) {
  var regexEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return regexEmail.test(String(email).toLowerCase());
}

const form = document.getElementById("registerform");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const confirmpassword = document.getElementById("confirm-password").value;
  const gender = document.getElementById("gender").value;
  const dob = document.getElementById("dob").value;

  //check email trước khi submit
  let legit = true;
  if (!validateEmail(email)) {
    document.getElementById("email-check").textContent = "Email không hợp lệ!";
    document.getElementById("email-check").classList.add("email-error");
    document.getElementById("email").classList.add("email-error-input");

    legit = false;
  } else {
    document.getElementById("email-check").textContent = "Email hợp lệ!";
    document.getElementById("email-check").classList.add("email-success");
  }
  //check password trước khi submit

  const confirmError = document.getElementById("confirm-error");

  if (password !== confirmpassword) {
    confirmError.textContent = "Mật khẩu xác nhận không khớp!";
    confirmError.classList.add("pw-error");
    document.getElementById("confirm-password").classList.add("pw-error-input");
    document.getElementById("password").classList.add("pw-error-input");
    legit = false;
  } else {
    confirmError.textContent = "Mật khẩu hợp lệ!";
    confirmError.classList.add("pw-success");
    document.getElementById("password").classList.add("pw-success-input");
    document
      .getElementById("confirm-password")
      .classList.add("pw-success-input");
  }
  //Nếu không hợp lệ thì dừng lại
  if (!legit) {
    alert("Không hợp lệ! Kiểm tra thông tin lại");
    return;
  }

  //lưu vào local storage
  localStorage.setItem("savedusername", username);
  localStorage.setItem("savedpassword", password);
  localStorage.setItem("savedemail", email);
  localStorage.setItem("savedcfpw", confirmpassword);
  localStorage.setItem("savedgender", gender);
  localStorage.setItem("saveddob", dob);

  //Thông báo đăng ký thành công
  const alert = document.getElementById("message");
  alert.textContent = "Đăng ký thành công";
  alert.className = "alert-success";
  alert.style.display = "block";
});
